﻿
namespace FijnstofGIP.FormsMenu
{
    partial class FormStatisticheData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.cmbWelkeMeter = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpDatumP1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTempAVG = new System.Windows.Forms.TextBox();
            this.pnlTempAVG = new System.Windows.Forms.Panel();
            this.txtLuchtdrukAVG = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtPM2_5AVG = new System.Windows.Forms.TextBox();
            this.pnl2_5PMAVG = new System.Windows.Forms.Panel();
            this.txtPM10AVG = new System.Windows.Forms.TextBox();
            this.pnlPM10AVG = new System.Windows.Forms.Panel();
            this.txtVochtigheidAVG = new System.Windows.Forms.TextBox();
            this.pnlVochtigheidAVG = new System.Windows.Forms.Panel();
            this.lblPM2_5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblVochtigheid = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtVochtigheidMIN = new System.Windows.Forms.TextBox();
            this.pnlVochtigheidMin = new System.Windows.Forms.Panel();
            this.txtPM2_5MIN = new System.Windows.Forms.TextBox();
            this.pnl2_5PMMin = new System.Windows.Forms.Panel();
            this.txtPM10MIN = new System.Windows.Forms.TextBox();
            this.pnl10PMMin = new System.Windows.Forms.Panel();
            this.txtTempMIN = new System.Windows.Forms.TextBox();
            this.pnlTempMin = new System.Windows.Forms.Panel();
            this.txtLuchtdrukMIN = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtVochtigheidMAX = new System.Windows.Forms.TextBox();
            this.pnlVochtigheidMAX = new System.Windows.Forms.Panel();
            this.txtPM2_5MAX = new System.Windows.Forms.TextBox();
            this.pnl2_5PMMax = new System.Windows.Forms.Panel();
            this.txtPM10MAX = new System.Windows.Forms.TextBox();
            this.pnl10PMMax = new System.Windows.Forms.Panel();
            this.txtTempMAX = new System.Windows.Forms.TextBox();
            this.pnlTempMax = new System.Windows.Forms.Panel();
            this.txtLuchtdrukMAX = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.btnClose = new FontAwesome.Sharp.IconPictureBox();
            this.dtpDatumP2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label2.Location = new System.Drawing.Point(331, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 37);
            this.label2.TabIndex = 20;
            this.label2.Text = "Statistische Data";
            this.label2.UseMnemonic = false;
            // 
            // cmbWelkeMeter
            // 
            this.cmbWelkeMeter.AccessibleDescription = "";
            this.cmbWelkeMeter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.cmbWelkeMeter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbWelkeMeter.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWelkeMeter.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.cmbWelkeMeter.FormattingEnabled = true;
            this.cmbWelkeMeter.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbWelkeMeter.ItemHeight = 14;
            this.cmbWelkeMeter.Location = new System.Drawing.Point(472, 122);
            this.cmbWelkeMeter.Name = "cmbWelkeMeter";
            this.cmbWelkeMeter.Size = new System.Drawing.Size(119, 22);
            this.cmbWelkeMeter.TabIndex = 82;
            this.cmbWelkeMeter.Tag = "Hier kan je kiezen in welk veld je wil zoeken";
            this.cmbWelkeMeter.SelectionChangeCommitted += new System.EventHandler(this.cmbWelkeMeter_SelectionChangeCommitted);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Myanmar Text", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label6.Location = new System.Drawing.Point(195, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(219, 23);
            this.label6.TabIndex = 81;
            this.label6.Text = "Kies hier de meter die u wilt inladen";
            // 
            // dtpDatumP1
            // 
            this.dtpDatumP1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDatumP1.Location = new System.Drawing.Point(338, 83);
            this.dtpDatumP1.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.dtpDatumP1.Name = "dtpDatumP1";
            this.dtpDatumP1.Size = new System.Drawing.Size(119, 20);
            this.dtpDatumP1.TabIndex = 83;
            this.dtpDatumP1.ValueChanged += new System.EventHandler(this.dtpDatum_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(195, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 23);
            this.label1.TabIndex = 84;
            this.label1.Text = "Kies hier uw periode";
            // 
            // txtTempAVG
            // 
            this.txtTempAVG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtTempAVG.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTempAVG.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTempAVG.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTempAVG.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtTempAVG.Location = new System.Drawing.Point(303, 330);
            this.txtTempAVG.MaxLength = 5;
            this.txtTempAVG.Multiline = true;
            this.txtTempAVG.Name = "txtTempAVG";
            this.txtTempAVG.ReadOnly = true;
            this.txtTempAVG.Size = new System.Drawing.Size(57, 20);
            this.txtTempAVG.TabIndex = 91;
            this.txtTempAVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlTempAVG
            // 
            this.pnlTempAVG.BackColor = System.Drawing.Color.White;
            this.pnlTempAVG.Location = new System.Drawing.Point(306, 349);
            this.pnlTempAVG.Margin = new System.Windows.Forms.Padding(0);
            this.pnlTempAVG.Name = "pnlTempAVG";
            this.pnlTempAVG.Size = new System.Drawing.Size(53, 3);
            this.pnlTempAVG.TabIndex = 92;
            // 
            // txtLuchtdrukAVG
            // 
            this.txtLuchtdrukAVG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtLuchtdrukAVG.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLuchtdrukAVG.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLuchtdrukAVG.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuchtdrukAVG.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtLuchtdrukAVG.Location = new System.Drawing.Point(366, 404);
            this.txtLuchtdrukAVG.MaxLength = 5;
            this.txtLuchtdrukAVG.Multiline = true;
            this.txtLuchtdrukAVG.Name = "txtLuchtdrukAVG";
            this.txtLuchtdrukAVG.ReadOnly = true;
            this.txtLuchtdrukAVG.Size = new System.Drawing.Size(57, 20);
            this.txtLuchtdrukAVG.TabIndex = 89;
            this.txtLuchtdrukAVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(369, 423);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(53, 3);
            this.panel3.TabIndex = 90;
            // 
            // txtPM2_5AVG
            // 
            this.txtPM2_5AVG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtPM2_5AVG.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPM2_5AVG.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPM2_5AVG.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPM2_5AVG.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPM2_5AVG.Location = new System.Drawing.Point(300, 259);
            this.txtPM2_5AVG.MaxLength = 5;
            this.txtPM2_5AVG.Multiline = true;
            this.txtPM2_5AVG.Name = "txtPM2_5AVG";
            this.txtPM2_5AVG.ReadOnly = true;
            this.txtPM2_5AVG.Size = new System.Drawing.Size(57, 20);
            this.txtPM2_5AVG.TabIndex = 95;
            this.txtPM2_5AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnl2_5PMAVG
            // 
            this.pnl2_5PMAVG.BackColor = System.Drawing.Color.White;
            this.pnl2_5PMAVG.Location = new System.Drawing.Point(303, 278);
            this.pnl2_5PMAVG.Margin = new System.Windows.Forms.Padding(0);
            this.pnl2_5PMAVG.Name = "pnl2_5PMAVG";
            this.pnl2_5PMAVG.Size = new System.Drawing.Size(53, 3);
            this.pnl2_5PMAVG.TabIndex = 96;
            // 
            // txtPM10AVG
            // 
            this.txtPM10AVG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtPM10AVG.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPM10AVG.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPM10AVG.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPM10AVG.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPM10AVG.Location = new System.Drawing.Point(415, 259);
            this.txtPM10AVG.MaxLength = 5;
            this.txtPM10AVG.Multiline = true;
            this.txtPM10AVG.Name = "txtPM10AVG";
            this.txtPM10AVG.ReadOnly = true;
            this.txtPM10AVG.Size = new System.Drawing.Size(57, 20);
            this.txtPM10AVG.TabIndex = 93;
            this.txtPM10AVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlPM10AVG
            // 
            this.pnlPM10AVG.BackColor = System.Drawing.Color.White;
            this.pnlPM10AVG.Location = new System.Drawing.Point(418, 278);
            this.pnlPM10AVG.Margin = new System.Windows.Forms.Padding(0);
            this.pnlPM10AVG.Name = "pnlPM10AVG";
            this.pnlPM10AVG.Size = new System.Drawing.Size(53, 3);
            this.pnlPM10AVG.TabIndex = 94;
            // 
            // txtVochtigheidAVG
            // 
            this.txtVochtigheidAVG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtVochtigheidAVG.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVochtigheidAVG.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtVochtigheidAVG.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVochtigheidAVG.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtVochtigheidAVG.Location = new System.Drawing.Point(416, 330);
            this.txtVochtigheidAVG.MaxLength = 5;
            this.txtVochtigheidAVG.Multiline = true;
            this.txtVochtigheidAVG.Name = "txtVochtigheidAVG";
            this.txtVochtigheidAVG.ReadOnly = true;
            this.txtVochtigheidAVG.Size = new System.Drawing.Size(57, 20);
            this.txtVochtigheidAVG.TabIndex = 99;
            this.txtVochtigheidAVG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlVochtigheidAVG
            // 
            this.pnlVochtigheidAVG.BackColor = System.Drawing.Color.White;
            this.pnlVochtigheidAVG.Location = new System.Drawing.Point(419, 349);
            this.pnlVochtigheidAVG.Margin = new System.Windows.Forms.Padding(0);
            this.pnlVochtigheidAVG.Name = "pnlVochtigheidAVG";
            this.pnlVochtigheidAVG.Size = new System.Drawing.Size(53, 3);
            this.pnlVochtigheidAVG.TabIndex = 100;
            // 
            // lblPM2_5
            // 
            this.lblPM2_5.AutoSize = true;
            this.lblPM2_5.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.lblPM2_5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPM2_5.Location = new System.Drawing.Point(304, 229);
            this.lblPM2_5.Name = "lblPM2_5";
            this.lblPM2_5.Size = new System.Drawing.Size(56, 27);
            this.lblPM2_5.TabIndex = 101;
            this.lblPM2_5.Text = "PM 2.5";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(422, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 27);
            this.label3.TabIndex = 102;
            this.label3.Text = "PM10";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label7.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label7.Location = new System.Drawing.Point(285, 300);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 27);
            this.label7.TabIndex = 104;
            this.label7.Text = "Temperatuur";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label8.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label8.Location = new System.Drawing.Point(361, 374);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 27);
            this.label8.TabIndex = 105;
            this.label8.Text = "Luchtdruk";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label9.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label9.Location = new System.Drawing.Point(352, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 27);
            this.label9.TabIndex = 106;
            this.label9.Text = "Gemiddelde";
            // 
            // lblVochtigheid
            // 
            this.lblVochtigheid.AutoSize = true;
            this.lblVochtigheid.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.lblVochtigheid.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblVochtigheid.Location = new System.Drawing.Point(402, 300);
            this.lblVochtigheid.Name = "lblVochtigheid";
            this.lblVochtigheid.Size = new System.Drawing.Size(92, 27);
            this.lblVochtigheid.TabIndex = 107;
            this.lblVochtigheid.Text = "Vochtigheid";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label5.Location = new System.Drawing.Point(120, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 27);
            this.label5.TabIndex = 123;
            this.label5.Text = "Vochtigheid";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label10.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label10.Location = new System.Drawing.Point(70, 190);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 27);
            this.label10.TabIndex = 122;
            this.label10.Text = "Minumum";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label11.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label11.Location = new System.Drawing.Point(20, 374);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 27);
            this.label11.TabIndex = 121;
            this.label11.Text = "Luchtdruk";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label12.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label12.Location = new System.Drawing.Point(5, 300);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 27);
            this.label12.TabIndex = 120;
            this.label12.Text = "Temperatuur";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label13.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label13.Location = new System.Drawing.Point(136, 229);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 27);
            this.label13.TabIndex = 119;
            this.label13.Text = "PM10";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label14.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label14.Location = new System.Drawing.Point(20, 229);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 27);
            this.label14.TabIndex = 118;
            this.label14.Text = "PM 2.5";
            // 
            // txtVochtigheidMIN
            // 
            this.txtVochtigheidMIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtVochtigheidMIN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVochtigheidMIN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtVochtigheidMIN.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVochtigheidMIN.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtVochtigheidMIN.Location = new System.Drawing.Point(134, 330);
            this.txtVochtigheidMIN.MaxLength = 45;
            this.txtVochtigheidMIN.Multiline = true;
            this.txtVochtigheidMIN.Name = "txtVochtigheidMIN";
            this.txtVochtigheidMIN.ReadOnly = true;
            this.txtVochtigheidMIN.Size = new System.Drawing.Size(57, 20);
            this.txtVochtigheidMIN.TabIndex = 116;
            this.txtVochtigheidMIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlVochtigheidMin
            // 
            this.pnlVochtigheidMin.BackColor = System.Drawing.Color.White;
            this.pnlVochtigheidMin.Location = new System.Drawing.Point(137, 349);
            this.pnlVochtigheidMin.Margin = new System.Windows.Forms.Padding(0);
            this.pnlVochtigheidMin.Name = "pnlVochtigheidMin";
            this.pnlVochtigheidMin.Size = new System.Drawing.Size(53, 3);
            this.pnlVochtigheidMin.TabIndex = 117;
            // 
            // txtPM2_5MIN
            // 
            this.txtPM2_5MIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtPM2_5MIN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPM2_5MIN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPM2_5MIN.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPM2_5MIN.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPM2_5MIN.Location = new System.Drawing.Point(18, 259);
            this.txtPM2_5MIN.MaxLength = 45;
            this.txtPM2_5MIN.Multiline = true;
            this.txtPM2_5MIN.Name = "txtPM2_5MIN";
            this.txtPM2_5MIN.ReadOnly = true;
            this.txtPM2_5MIN.Size = new System.Drawing.Size(57, 20);
            this.txtPM2_5MIN.TabIndex = 114;
            this.txtPM2_5MIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnl2_5PMMin
            // 
            this.pnl2_5PMMin.BackColor = System.Drawing.Color.White;
            this.pnl2_5PMMin.Location = new System.Drawing.Point(21, 278);
            this.pnl2_5PMMin.Margin = new System.Windows.Forms.Padding(0);
            this.pnl2_5PMMin.Name = "pnl2_5PMMin";
            this.pnl2_5PMMin.Size = new System.Drawing.Size(53, 3);
            this.pnl2_5PMMin.TabIndex = 115;
            // 
            // txtPM10MIN
            // 
            this.txtPM10MIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtPM10MIN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPM10MIN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPM10MIN.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPM10MIN.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPM10MIN.Location = new System.Drawing.Point(133, 259);
            this.txtPM10MIN.MaxLength = 45;
            this.txtPM10MIN.Multiline = true;
            this.txtPM10MIN.Name = "txtPM10MIN";
            this.txtPM10MIN.ReadOnly = true;
            this.txtPM10MIN.Size = new System.Drawing.Size(57, 20);
            this.txtPM10MIN.TabIndex = 112;
            this.txtPM10MIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnl10PMMin
            // 
            this.pnl10PMMin.BackColor = System.Drawing.Color.White;
            this.pnl10PMMin.Location = new System.Drawing.Point(136, 278);
            this.pnl10PMMin.Margin = new System.Windows.Forms.Padding(0);
            this.pnl10PMMin.Name = "pnl10PMMin";
            this.pnl10PMMin.Size = new System.Drawing.Size(53, 3);
            this.pnl10PMMin.TabIndex = 113;
            // 
            // txtTempMIN
            // 
            this.txtTempMIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtTempMIN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTempMIN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTempMIN.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTempMIN.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtTempMIN.Location = new System.Drawing.Point(21, 330);
            this.txtTempMIN.MaxLength = 45;
            this.txtTempMIN.Multiline = true;
            this.txtTempMIN.Name = "txtTempMIN";
            this.txtTempMIN.ReadOnly = true;
            this.txtTempMIN.Size = new System.Drawing.Size(57, 20);
            this.txtTempMIN.TabIndex = 110;
            this.txtTempMIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlTempMin
            // 
            this.pnlTempMin.BackColor = System.Drawing.Color.White;
            this.pnlTempMin.Location = new System.Drawing.Point(24, 349);
            this.pnlTempMin.Margin = new System.Windows.Forms.Padding(0);
            this.pnlTempMin.Name = "pnlTempMin";
            this.pnlTempMin.Size = new System.Drawing.Size(53, 3);
            this.pnlTempMin.TabIndex = 111;
            // 
            // txtLuchtdrukMIN
            // 
            this.txtLuchtdrukMIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtLuchtdrukMIN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLuchtdrukMIN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLuchtdrukMIN.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuchtdrukMIN.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtLuchtdrukMIN.Location = new System.Drawing.Point(25, 404);
            this.txtLuchtdrukMIN.MaxLength = 45;
            this.txtLuchtdrukMIN.Multiline = true;
            this.txtLuchtdrukMIN.Name = "txtLuchtdrukMIN";
            this.txtLuchtdrukMIN.ReadOnly = true;
            this.txtLuchtdrukMIN.Size = new System.Drawing.Size(57, 20);
            this.txtLuchtdrukMIN.TabIndex = 108;
            this.txtLuchtdrukMIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Location = new System.Drawing.Point(28, 423);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(53, 3);
            this.panel10.TabIndex = 109;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label15.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label15.Location = new System.Drawing.Point(669, 300);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 27);
            this.label15.TabIndex = 139;
            this.label15.Text = "Vochtigheid";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label16.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label16.Location = new System.Drawing.Point(618, 190);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 27);
            this.label16.TabIndex = 138;
            this.label16.Text = "Maximum";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label17.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label17.Location = new System.Drawing.Point(682, 374);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 27);
            this.label17.TabIndex = 137;
            this.label17.Text = "Luchtdruk";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label18.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label18.Location = new System.Drawing.Point(555, 300);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(97, 27);
            this.label18.TabIndex = 136;
            this.label18.Text = "Temperatuur";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label19.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label19.Location = new System.Drawing.Point(690, 229);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 27);
            this.label19.TabIndex = 135;
            this.label19.Text = "PM10";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Myanmar Text", 11.25F);
            this.label20.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label20.Location = new System.Drawing.Point(572, 229);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 27);
            this.label20.TabIndex = 134;
            this.label20.Text = "PM 2.5";
            // 
            // txtVochtigheidMAX
            // 
            this.txtVochtigheidMAX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtVochtigheidMAX.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVochtigheidMAX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtVochtigheidMAX.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVochtigheidMAX.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtVochtigheidMAX.Location = new System.Drawing.Point(685, 330);
            this.txtVochtigheidMAX.MaxLength = 45;
            this.txtVochtigheidMAX.Multiline = true;
            this.txtVochtigheidMAX.Name = "txtVochtigheidMAX";
            this.txtVochtigheidMAX.ReadOnly = true;
            this.txtVochtigheidMAX.Size = new System.Drawing.Size(57, 20);
            this.txtVochtigheidMAX.TabIndex = 132;
            this.txtVochtigheidMAX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlVochtigheidMAX
            // 
            this.pnlVochtigheidMAX.BackColor = System.Drawing.Color.White;
            this.pnlVochtigheidMAX.Location = new System.Drawing.Point(688, 349);
            this.pnlVochtigheidMAX.Margin = new System.Windows.Forms.Padding(0);
            this.pnlVochtigheidMAX.Name = "pnlVochtigheidMAX";
            this.pnlVochtigheidMAX.Size = new System.Drawing.Size(53, 3);
            this.pnlVochtigheidMAX.TabIndex = 133;
            // 
            // txtPM2_5MAX
            // 
            this.txtPM2_5MAX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtPM2_5MAX.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPM2_5MAX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPM2_5MAX.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPM2_5MAX.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPM2_5MAX.Location = new System.Drawing.Point(569, 259);
            this.txtPM2_5MAX.MaxLength = 45;
            this.txtPM2_5MAX.Multiline = true;
            this.txtPM2_5MAX.Name = "txtPM2_5MAX";
            this.txtPM2_5MAX.ReadOnly = true;
            this.txtPM2_5MAX.Size = new System.Drawing.Size(57, 20);
            this.txtPM2_5MAX.TabIndex = 130;
            this.txtPM2_5MAX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnl2_5PMMax
            // 
            this.pnl2_5PMMax.BackColor = System.Drawing.Color.White;
            this.pnl2_5PMMax.Location = new System.Drawing.Point(572, 278);
            this.pnl2_5PMMax.Margin = new System.Windows.Forms.Padding(0);
            this.pnl2_5PMMax.Name = "pnl2_5PMMax";
            this.pnl2_5PMMax.Size = new System.Drawing.Size(53, 3);
            this.pnl2_5PMMax.TabIndex = 131;
            // 
            // txtPM10MAX
            // 
            this.txtPM10MAX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtPM10MAX.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPM10MAX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPM10MAX.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPM10MAX.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPM10MAX.Location = new System.Drawing.Point(684, 259);
            this.txtPM10MAX.MaxLength = 45;
            this.txtPM10MAX.Multiline = true;
            this.txtPM10MAX.Name = "txtPM10MAX";
            this.txtPM10MAX.ReadOnly = true;
            this.txtPM10MAX.Size = new System.Drawing.Size(57, 20);
            this.txtPM10MAX.TabIndex = 128;
            this.txtPM10MAX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnl10PMMax
            // 
            this.pnl10PMMax.BackColor = System.Drawing.Color.White;
            this.pnl10PMMax.Location = new System.Drawing.Point(687, 278);
            this.pnl10PMMax.Margin = new System.Windows.Forms.Padding(0);
            this.pnl10PMMax.Name = "pnl10PMMax";
            this.pnl10PMMax.Size = new System.Drawing.Size(53, 3);
            this.pnl10PMMax.TabIndex = 129;
            // 
            // txtTempMAX
            // 
            this.txtTempMAX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtTempMAX.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTempMAX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTempMAX.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTempMAX.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtTempMAX.Location = new System.Drawing.Point(572, 330);
            this.txtTempMAX.MaxLength = 45;
            this.txtTempMAX.Multiline = true;
            this.txtTempMAX.Name = "txtTempMAX";
            this.txtTempMAX.ReadOnly = true;
            this.txtTempMAX.Size = new System.Drawing.Size(57, 20);
            this.txtTempMAX.TabIndex = 126;
            this.txtTempMAX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlTempMax
            // 
            this.pnlTempMax.BackColor = System.Drawing.Color.White;
            this.pnlTempMax.Location = new System.Drawing.Point(575, 349);
            this.pnlTempMax.Margin = new System.Windows.Forms.Padding(0);
            this.pnlTempMax.Name = "pnlTempMax";
            this.pnlTempMax.Size = new System.Drawing.Size(53, 3);
            this.pnlTempMax.TabIndex = 127;
            // 
            // txtLuchtdrukMAX
            // 
            this.txtLuchtdrukMAX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.txtLuchtdrukMAX.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLuchtdrukMAX.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLuchtdrukMAX.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLuchtdrukMAX.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtLuchtdrukMAX.Location = new System.Drawing.Point(688, 404);
            this.txtLuchtdrukMAX.MaxLength = 45;
            this.txtLuchtdrukMAX.Multiline = true;
            this.txtLuchtdrukMAX.Name = "txtLuchtdrukMAX";
            this.txtLuchtdrukMAX.ReadOnly = true;
            this.txtLuchtdrukMAX.Size = new System.Drawing.Size(57, 20);
            this.txtLuchtdrukMAX.TabIndex = 124;
            this.txtLuchtdrukMAX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Location = new System.Drawing.Point(691, 423);
            this.panel15.Margin = new System.Windows.Forms.Padding(0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(53, 3);
            this.panel15.TabIndex = 125;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.btnClose.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnClose.IconColor = System.Drawing.Color.DeepSkyBlue;
            this.btnClose.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnClose.IconSize = 20;
            this.btnClose.Location = new System.Drawing.Point(780, 2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(20, 21);
            this.btnClose.TabIndex = 140;
            this.btnClose.TabStop = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dtpDatumP2
            // 
            this.dtpDatumP2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDatumP2.Location = new System.Drawing.Point(472, 83);
            this.dtpDatumP2.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.dtpDatumP2.Name = "dtpDatumP2";
            this.dtpDatumP2.Size = new System.Drawing.Size(119, 20);
            this.dtpDatumP2.TabIndex = 141;
            this.dtpDatumP2.ValueChanged += new System.EventHandler(this.dtpDatumP2_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label4.Location = new System.Drawing.Point(81, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 18);
            this.label4.TabIndex = 142;
            this.label4.Text = "µg/m";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label21.Location = new System.Drawing.Point(196, 259);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 18);
            this.label21.TabIndex = 143;
            this.label21.Text = "µg/m";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label22.Location = new System.Drawing.Point(360, 260);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 18);
            this.label22.TabIndex = 144;
            this.label22.Text = "µg/m";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label23.Location = new System.Drawing.Point(475, 259);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 18);
            this.label23.TabIndex = 145;
            this.label23.Text = "µg/m";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label24.Location = new System.Drawing.Point(632, 259);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 18);
            this.label24.TabIndex = 146;
            this.label24.Text = "µg/m";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label25.Location = new System.Drawing.Point(743, 259);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 18);
            this.label25.TabIndex = 147;
            this.label25.Text = "µg/m";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label26.Location = new System.Drawing.Point(81, 332);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(25, 18);
            this.label26.TabIndex = 148;
            this.label26.Text = "°C";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label27.Location = new System.Drawing.Point(359, 334);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(25, 18);
            this.label27.TabIndex = 149;
            this.label27.Text = "°C";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label28.Location = new System.Drawing.Point(633, 334);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(25, 18);
            this.label28.TabIndex = 150;
            this.label28.Text = "°C";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label29.Location = new System.Drawing.Point(196, 332);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(21, 18);
            this.label29.TabIndex = 151;
            this.label29.Text = "%";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label30.Location = new System.Drawing.Point(475, 334);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(21, 18);
            this.label30.TabIndex = 152;
            this.label30.Text = "%";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label31.Location = new System.Drawing.Point(745, 334);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(21, 18);
            this.label31.TabIndex = 153;
            this.label31.Text = "%";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label32.Location = new System.Drawing.Point(429, 410);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(32, 16);
            this.label32.TabIndex = 154;
            this.label32.Text = "hPa";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label33.Location = new System.Drawing.Point(747, 410);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(32, 16);
            this.label33.TabIndex = 155;
            this.label33.Text = "hPa";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label34.Location = new System.Drawing.Point(88, 410);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(32, 16);
            this.label34.TabIndex = 156;
            this.label34.Text = "hPa";
            // 
            // FormStatisticheData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(807, 540);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpDatumP2);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtVochtigheidMAX);
            this.Controls.Add(this.pnlVochtigheidMAX);
            this.Controls.Add(this.txtPM2_5MAX);
            this.Controls.Add(this.pnl2_5PMMax);
            this.Controls.Add(this.txtPM10MAX);
            this.Controls.Add(this.pnl10PMMax);
            this.Controls.Add(this.txtTempMAX);
            this.Controls.Add(this.pnlTempMax);
            this.Controls.Add(this.txtLuchtdrukMAX);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtVochtigheidMIN);
            this.Controls.Add(this.pnlVochtigheidMin);
            this.Controls.Add(this.txtPM2_5MIN);
            this.Controls.Add(this.pnl2_5PMMin);
            this.Controls.Add(this.txtPM10MIN);
            this.Controls.Add(this.pnl10PMMin);
            this.Controls.Add(this.txtTempMIN);
            this.Controls.Add(this.pnlTempMin);
            this.Controls.Add(this.txtLuchtdrukMIN);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.lblVochtigheid);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblPM2_5);
            this.Controls.Add(this.txtVochtigheidAVG);
            this.Controls.Add(this.pnlVochtigheidAVG);
            this.Controls.Add(this.txtPM2_5AVG);
            this.Controls.Add(this.pnl2_5PMAVG);
            this.Controls.Add(this.txtPM10AVG);
            this.Controls.Add(this.pnlPM10AVG);
            this.Controls.Add(this.txtTempAVG);
            this.Controls.Add(this.pnlTempAVG);
            this.Controls.Add(this.txtLuchtdrukAVG);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpDatumP1);
            this.Controls.Add(this.cmbWelkeMeter);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Name = "FormStatisticheData";
            this.Text = "FormStatisticheData";
            this.Load += new System.EventHandler(this.FormStatisticheData_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbWelkeMeter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpDatumP1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTempAVG;
        private System.Windows.Forms.Panel pnlTempAVG;
        private System.Windows.Forms.TextBox txtLuchtdrukAVG;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtPM2_5AVG;
        private System.Windows.Forms.Panel pnl2_5PMAVG;
        private System.Windows.Forms.TextBox txtPM10AVG;
        private System.Windows.Forms.Panel pnlPM10AVG;
        private System.Windows.Forms.TextBox txtVochtigheidAVG;
        private System.Windows.Forms.Panel pnlVochtigheidAVG;
        private System.Windows.Forms.Label lblPM2_5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblVochtigheid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtVochtigheidMIN;
        private System.Windows.Forms.Panel pnlVochtigheidMin;
        private System.Windows.Forms.TextBox txtPM2_5MIN;
        private System.Windows.Forms.Panel pnl2_5PMMin;
        private System.Windows.Forms.TextBox txtPM10MIN;
        private System.Windows.Forms.Panel pnl10PMMin;
        private System.Windows.Forms.TextBox txtTempMIN;
        private System.Windows.Forms.Panel pnlTempMin;
        private System.Windows.Forms.TextBox txtLuchtdrukMIN;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtVochtigheidMAX;
        private System.Windows.Forms.Panel pnlVochtigheidMAX;
        private System.Windows.Forms.TextBox txtPM2_5MAX;
        private System.Windows.Forms.Panel pnl2_5PMMax;
        private System.Windows.Forms.TextBox txtPM10MAX;
        private System.Windows.Forms.Panel pnl10PMMax;
        private System.Windows.Forms.TextBox txtTempMAX;
        private System.Windows.Forms.Panel pnlTempMax;
        private System.Windows.Forms.TextBox txtLuchtdrukMAX;
        private System.Windows.Forms.Panel panel15;
        private FontAwesome.Sharp.IconPictureBox btnClose;
        private System.Windows.Forms.DateTimePicker dtpDatumP2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
    }
}