﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FijnstofGIP
{
    class InfoGebruiker
    {   //info gebruiker
        public static string gebruikersID = "";
        public static string gebruikersnaam = "";
        public static string voornaam = "";
        public static string familienaam = "";
        public static string email = "";
        public static string straat = "";
        public static string huisnummer = "";
        public static string postcode = "";
        public static string gemeente = "";

        //info mail kalex
        public static string KalexWW = "eY2d2Cwd2DKd3VG";
        public static string KalexEmail = "kalex.fijnstofmeter@gmail.com";
    }
}
