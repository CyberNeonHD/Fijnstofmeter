﻿
namespace FijnstofGIP
{
    partial class Registratiescherm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlgebruikersnaam = new System.Windows.Forms.Panel();
            this.txtGebruikersnaam = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlvoornaam = new System.Windows.Forms.Panel();
            this.txtVoornaam = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlfamilie = new System.Windows.Forms.Panel();
            this.txtFamilienaam = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlstraat = new System.Windows.Forms.Panel();
            this.txtStraat = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pnlpostcode = new System.Windows.Forms.Panel();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pnlhuisnummer = new System.Windows.Forms.Panel();
            this.txtHuisNummer = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pnlgemeente = new System.Windows.Forms.Panel();
            this.txtGemeente = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pnlww = new System.Windows.Forms.Panel();
            this.txtWachtwoord = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.pnlwwbevestigen = new System.Windows.Forms.Panel();
            this.txtWachtwoordBevestigen = new System.Windows.Forms.TextBox();
            this.btnRegistreren = new System.Windows.Forms.Button();
            this.btnNaarLogin = new System.Windows.Forms.Button();
            this.iconbtnLock = new FontAwesome.Sharp.IconPictureBox();
            this.iconbtnOpenLock = new FontAwesome.Sharp.IconPictureBox();
            this.iconbtnOpenLockBevestigen = new FontAwesome.Sharp.IconPictureBox();
            this.iconbtnLockBevestigen = new FontAwesome.Sharp.IconPictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pnlEmail = new System.Windows.Forms.Panel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblVerplichtVeld = new System.Windows.Forms.Label();
            this.ToolTip = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnLock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnOpenLock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnOpenLockBevestigen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnLockBevestigen)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(141, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Maak jouw account aan";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label2.Location = new System.Drawing.Point(17, 277);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Gebruikersnaam*";
            // 
            // pnlgebruikersnaam
            // 
            this.pnlgebruikersnaam.BackColor = System.Drawing.Color.White;
            this.pnlgebruikersnaam.Location = new System.Drawing.Point(21, 322);
            this.pnlgebruikersnaam.Margin = new System.Windows.Forms.Padding(0);
            this.pnlgebruikersnaam.Name = "pnlgebruikersnaam";
            this.pnlgebruikersnaam.Size = new System.Drawing.Size(226, 3);
            this.pnlgebruikersnaam.TabIndex = 3;
            // 
            // txtGebruikersnaam
            // 
            this.txtGebruikersnaam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtGebruikersnaam.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGebruikersnaam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGebruikersnaam.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGebruikersnaam.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtGebruikersnaam.Location = new System.Drawing.Point(16, 303);
            this.txtGebruikersnaam.MaxLength = 30;
            this.txtGebruikersnaam.Multiline = true;
            this.txtGebruikersnaam.Name = "txtGebruikersnaam";
            this.txtGebruikersnaam.Size = new System.Drawing.Size(240, 20);
            this.txtGebruikersnaam.TabIndex = 7;
            this.txtGebruikersnaam.Click += new System.EventHandler(this.txtGebruikersnaam_Click);
            this.txtGebruikersnaam.Enter += new System.EventHandler(this.txtGebruikersnaam_Enter);
            this.txtGebruikersnaam.Leave += new System.EventHandler(this.txtGebruikersnaam_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(15, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 27);
            this.label3.TabIndex = 1;
            this.label3.Text = "Voornaam*";
            // 
            // pnlvoornaam
            // 
            this.pnlvoornaam.BackColor = System.Drawing.Color.White;
            this.pnlvoornaam.Location = new System.Drawing.Point(21, 117);
            this.pnlvoornaam.Margin = new System.Windows.Forms.Padding(0);
            this.pnlvoornaam.Name = "pnlvoornaam";
            this.pnlvoornaam.Size = new System.Drawing.Size(226, 3);
            this.pnlvoornaam.TabIndex = 3;
            // 
            // txtVoornaam
            // 
            this.txtVoornaam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtVoornaam.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVoornaam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtVoornaam.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVoornaam.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtVoornaam.Location = new System.Drawing.Point(16, 98);
            this.txtVoornaam.MaxLength = 27;
            this.txtVoornaam.Multiline = true;
            this.txtVoornaam.Name = "txtVoornaam";
            this.txtVoornaam.Size = new System.Drawing.Size(240, 20);
            this.txtVoornaam.TabIndex = 1;
            this.txtVoornaam.Click += new System.EventHandler(this.txtVoornaam_Click);
            this.txtVoornaam.Enter += new System.EventHandler(this.txtVoornaam_Enter);
            this.txtVoornaam.Leave += new System.EventHandler(this.txtVoornaam_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label4.Location = new System.Drawing.Point(275, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 27);
            this.label4.TabIndex = 1;
            this.label4.Text = "Familienaam*";
            // 
            // pnlfamilie
            // 
            this.pnlfamilie.BackColor = System.Drawing.Color.White;
            this.pnlfamilie.Location = new System.Drawing.Point(281, 117);
            this.pnlfamilie.Margin = new System.Windows.Forms.Padding(0);
            this.pnlfamilie.Name = "pnlfamilie";
            this.pnlfamilie.Size = new System.Drawing.Size(230, 3);
            this.pnlfamilie.TabIndex = 3;
            // 
            // txtFamilienaam
            // 
            this.txtFamilienaam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtFamilienaam.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFamilienaam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFamilienaam.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFamilienaam.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtFamilienaam.Location = new System.Drawing.Point(278, 98);
            this.txtFamilienaam.MaxLength = 45;
            this.txtFamilienaam.Multiline = true;
            this.txtFamilienaam.Name = "txtFamilienaam";
            this.txtFamilienaam.Size = new System.Drawing.Size(234, 20);
            this.txtFamilienaam.TabIndex = 2;
            this.txtFamilienaam.Click += new System.EventHandler(this.txtFamilienaam_Click);
            this.txtFamilienaam.Enter += new System.EventHandler(this.txtFamilienaam_Enter);
            this.txtFamilienaam.Leave += new System.EventHandler(this.txtFamilienaam_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label5.Location = new System.Drawing.Point(16, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 27);
            this.label5.TabIndex = 1;
            this.label5.Text = "Straat";
            // 
            // pnlstraat
            // 
            this.pnlstraat.BackColor = System.Drawing.Color.White;
            this.pnlstraat.Location = new System.Drawing.Point(21, 182);
            this.pnlstraat.Margin = new System.Windows.Forms.Padding(0);
            this.pnlstraat.Name = "pnlstraat";
            this.pnlstraat.Size = new System.Drawing.Size(226, 3);
            this.pnlstraat.TabIndex = 3;
            // 
            // txtStraat
            // 
            this.txtStraat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtStraat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtStraat.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtStraat.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStraat.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtStraat.Location = new System.Drawing.Point(16, 163);
            this.txtStraat.MaxLength = 27;
            this.txtStraat.Multiline = true;
            this.txtStraat.Name = "txtStraat";
            this.txtStraat.Size = new System.Drawing.Size(240, 20);
            this.txtStraat.TabIndex = 3;
            this.txtStraat.Click += new System.EventHandler(this.txtStraat_Click);
            this.txtStraat.Enter += new System.EventHandler(this.txtStraat_Enter);
            this.txtStraat.Leave += new System.EventHandler(this.txtStraat_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label6.Location = new System.Drawing.Point(275, 208);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 27);
            this.label6.TabIndex = 1;
            this.label6.Text = "Postcode";
            // 
            // pnlpostcode
            // 
            this.pnlpostcode.BackColor = System.Drawing.Color.White;
            this.pnlpostcode.Location = new System.Drawing.Point(281, 253);
            this.pnlpostcode.Margin = new System.Windows.Forms.Padding(0);
            this.pnlpostcode.Name = "pnlpostcode";
            this.pnlpostcode.Size = new System.Drawing.Size(74, 3);
            this.pnlpostcode.TabIndex = 3;
            // 
            // txtPostcode
            // 
            this.txtPostcode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtPostcode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPostcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPostcode.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPostcode.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtPostcode.Location = new System.Drawing.Point(278, 234);
            this.txtPostcode.MaxLength = 4;
            this.txtPostcode.Multiline = true;
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.Size = new System.Drawing.Size(78, 20);
            this.txtPostcode.TabIndex = 6;
            this.txtPostcode.Click += new System.EventHandler(this.txtPostcode_Click);
            this.txtPostcode.Enter += new System.EventHandler(this.txtPostcode_Enter);
            this.txtPostcode.Leave += new System.EventHandler(this.txtPostcode_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label7.Location = new System.Drawing.Point(276, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 27);
            this.label7.TabIndex = 1;
            this.label7.Text = "Nummer";
            // 
            // pnlhuisnummer
            // 
            this.pnlhuisnummer.BackColor = System.Drawing.Color.White;
            this.pnlhuisnummer.Location = new System.Drawing.Point(282, 182);
            this.pnlhuisnummer.Margin = new System.Windows.Forms.Padding(0);
            this.pnlhuisnummer.Name = "pnlhuisnummer";
            this.pnlhuisnummer.Size = new System.Drawing.Size(73, 3);
            this.pnlhuisnummer.TabIndex = 3;
            // 
            // txtHuisNummer
            // 
            this.txtHuisNummer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtHuisNummer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHuisNummer.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtHuisNummer.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHuisNummer.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtHuisNummer.Location = new System.Drawing.Point(279, 163);
            this.txtHuisNummer.MaxLength = 5;
            this.txtHuisNummer.Multiline = true;
            this.txtHuisNummer.Name = "txtHuisNummer";
            this.txtHuisNummer.Size = new System.Drawing.Size(77, 20);
            this.txtHuisNummer.TabIndex = 4;
            this.txtHuisNummer.Click += new System.EventHandler(this.txtHuisNummer_Click);
            this.txtHuisNummer.Enter += new System.EventHandler(this.txtHuisNummer_Enter);
            this.txtHuisNummer.Leave += new System.EventHandler(this.txtHuisNummer_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label8.Location = new System.Drawing.Point(16, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 27);
            this.label8.TabIndex = 1;
            this.label8.Text = "Gemeente";
            // 
            // pnlgemeente
            // 
            this.pnlgemeente.BackColor = System.Drawing.Color.White;
            this.pnlgemeente.Location = new System.Drawing.Point(21, 253);
            this.pnlgemeente.Margin = new System.Windows.Forms.Padding(0);
            this.pnlgemeente.Name = "pnlgemeente";
            this.pnlgemeente.Size = new System.Drawing.Size(226, 3);
            this.pnlgemeente.TabIndex = 3;
            // 
            // txtGemeente
            // 
            this.txtGemeente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtGemeente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGemeente.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGemeente.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGemeente.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtGemeente.Location = new System.Drawing.Point(16, 234);
            this.txtGemeente.MaxLength = 27;
            this.txtGemeente.Multiline = true;
            this.txtGemeente.Name = "txtGemeente";
            this.txtGemeente.Size = new System.Drawing.Size(240, 20);
            this.txtGemeente.TabIndex = 5;
            this.txtGemeente.Click += new System.EventHandler(this.txtGemeente_Click);
            this.txtGemeente.Enter += new System.EventHandler(this.txtGemeente_Enter);
            this.txtGemeente.Leave += new System.EventHandler(this.txtGemeente_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label9.Location = new System.Drawing.Point(17, 340);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 27);
            this.label9.TabIndex = 1;
            this.label9.Text = "Wachtwoord*";
            // 
            // pnlww
            // 
            this.pnlww.BackColor = System.Drawing.Color.White;
            this.pnlww.Location = new System.Drawing.Point(21, 385);
            this.pnlww.Margin = new System.Windows.Forms.Padding(0);
            this.pnlww.Name = "pnlww";
            this.pnlww.Size = new System.Drawing.Size(226, 3);
            this.pnlww.TabIndex = 3;
            // 
            // txtWachtwoord
            // 
            this.txtWachtwoord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtWachtwoord.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtWachtwoord.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWachtwoord.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWachtwoord.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtWachtwoord.Location = new System.Drawing.Point(16, 366);
            this.txtWachtwoord.MaxLength = 27;
            this.txtWachtwoord.Multiline = true;
            this.txtWachtwoord.Name = "txtWachtwoord";
            this.txtWachtwoord.PasswordChar = '*';
            this.txtWachtwoord.Size = new System.Drawing.Size(240, 20);
            this.txtWachtwoord.TabIndex = 9;
            this.txtWachtwoord.Click += new System.EventHandler(this.txtWachtwoord_Click);
            this.txtWachtwoord.Enter += new System.EventHandler(this.txtWachtwoord_Enter);
            this.txtWachtwoord.Leave += new System.EventHandler(this.txtWachtwoord_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label10.Location = new System.Drawing.Point(273, 340);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(179, 27);
            this.label10.TabIndex = 1;
            this.label10.Text = "Wachtwoord bevestigen*";
            // 
            // pnlwwbevestigen
            // 
            this.pnlwwbevestigen.BackColor = System.Drawing.Color.White;
            this.pnlwwbevestigen.Location = new System.Drawing.Point(279, 385);
            this.pnlwwbevestigen.Margin = new System.Windows.Forms.Padding(0);
            this.pnlwwbevestigen.Name = "pnlwwbevestigen";
            this.pnlwwbevestigen.Size = new System.Drawing.Size(233, 3);
            this.pnlwwbevestigen.TabIndex = 3;
            // 
            // txtWachtwoordBevestigen
            // 
            this.txtWachtwoordBevestigen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtWachtwoordBevestigen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtWachtwoordBevestigen.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWachtwoordBevestigen.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWachtwoordBevestigen.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtWachtwoordBevestigen.Location = new System.Drawing.Point(276, 366);
            this.txtWachtwoordBevestigen.MaxLength = 27;
            this.txtWachtwoordBevestigen.Multiline = true;
            this.txtWachtwoordBevestigen.Name = "txtWachtwoordBevestigen";
            this.txtWachtwoordBevestigen.PasswordChar = '*';
            this.txtWachtwoordBevestigen.Size = new System.Drawing.Size(237, 20);
            this.txtWachtwoordBevestigen.TabIndex = 10;
            this.txtWachtwoordBevestigen.Click += new System.EventHandler(this.txtWachtwoordBevestigen_Click);
            this.txtWachtwoordBevestigen.Enter += new System.EventHandler(this.txtWachtwoordBevestigen_Enter);
            this.txtWachtwoordBevestigen.Leave += new System.EventHandler(this.txtWachtwoordBevestigen_Leave);
            // 
            // btnRegistreren
            // 
            this.btnRegistreren.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistreren.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistreren.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.btnRegistreren.Location = new System.Drawing.Point(385, 418);
            this.btnRegistreren.Name = "btnRegistreren";
            this.btnRegistreren.Size = new System.Drawing.Size(129, 34);
            this.btnRegistreren.TabIndex = 12;
            this.btnRegistreren.Text = "Registreren";
            this.btnRegistreren.UseVisualStyleBackColor = true;
            this.btnRegistreren.Click += new System.EventHandler(this.btnRegistreren_Click);
            // 
            // btnNaarLogin
            // 
            this.btnNaarLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNaarLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNaarLogin.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.btnNaarLogin.Location = new System.Drawing.Point(246, 418);
            this.btnNaarLogin.Name = "btnNaarLogin";
            this.btnNaarLogin.Size = new System.Drawing.Size(126, 34);
            this.btnNaarLogin.TabIndex = 11;
            this.btnNaarLogin.Text = "Terugkeren";
            this.btnNaarLogin.UseVisualStyleBackColor = true;
            this.btnNaarLogin.Click += new System.EventHandler(this.btnNaarLogin_Click);
            // 
            // iconbtnLock
            // 
            this.iconbtnLock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.iconbtnLock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconbtnLock.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnLock.IconChar = FontAwesome.Sharp.IconChar.Lock;
            this.iconbtnLock.IconColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnLock.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconbtnLock.IconSize = 24;
            this.iconbtnLock.Location = new System.Drawing.Point(223, 340);
            this.iconbtnLock.Name = "iconbtnLock";
            this.iconbtnLock.Size = new System.Drawing.Size(24, 24);
            this.iconbtnLock.TabIndex = 6;
            this.iconbtnLock.TabStop = false;
            this.iconbtnLock.Click += new System.EventHandler(this.iconbtnLock_Click);
            this.iconbtnLock.MouseHover += new System.EventHandler(this.iconbtnLock_MouseHover);
            // 
            // iconbtnOpenLock
            // 
            this.iconbtnOpenLock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.iconbtnOpenLock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconbtnOpenLock.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnOpenLock.IconChar = FontAwesome.Sharp.IconChar.LockOpen;
            this.iconbtnOpenLock.IconColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnOpenLock.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconbtnOpenLock.IconSize = 24;
            this.iconbtnOpenLock.Location = new System.Drawing.Point(223, 340);
            this.iconbtnOpenLock.Name = "iconbtnOpenLock";
            this.iconbtnOpenLock.Size = new System.Drawing.Size(24, 24);
            this.iconbtnOpenLock.TabIndex = 6;
            this.iconbtnOpenLock.TabStop = false;
            this.iconbtnOpenLock.Click += new System.EventHandler(this.iconbtnOpenLock_Click);
            this.iconbtnOpenLock.MouseHover += new System.EventHandler(this.iconbtnOpenLock_MouseHover);
            // 
            // iconbtnOpenLockBevestigen
            // 
            this.iconbtnOpenLockBevestigen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.iconbtnOpenLockBevestigen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconbtnOpenLockBevestigen.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnOpenLockBevestigen.IconChar = FontAwesome.Sharp.IconChar.LockOpen;
            this.iconbtnOpenLockBevestigen.IconColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnOpenLockBevestigen.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconbtnOpenLockBevestigen.IconSize = 24;
            this.iconbtnOpenLockBevestigen.Location = new System.Drawing.Point(488, 340);
            this.iconbtnOpenLockBevestigen.Name = "iconbtnOpenLockBevestigen";
            this.iconbtnOpenLockBevestigen.Size = new System.Drawing.Size(24, 24);
            this.iconbtnOpenLockBevestigen.TabIndex = 6;
            this.iconbtnOpenLockBevestigen.TabStop = false;
            this.iconbtnOpenLockBevestigen.Click += new System.EventHandler(this.iconbtnOpenLockBevestigen_Click);
            this.iconbtnOpenLockBevestigen.MouseHover += new System.EventHandler(this.iconbtnOpenLockBevestigen_MouseHover);
            // 
            // iconbtnLockBevestigen
            // 
            this.iconbtnLockBevestigen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.iconbtnLockBevestigen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconbtnLockBevestigen.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnLockBevestigen.IconChar = FontAwesome.Sharp.IconChar.Lock;
            this.iconbtnLockBevestigen.IconColor = System.Drawing.Color.DeepSkyBlue;
            this.iconbtnLockBevestigen.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconbtnLockBevestigen.IconSize = 24;
            this.iconbtnLockBevestigen.Location = new System.Drawing.Point(488, 340);
            this.iconbtnLockBevestigen.Name = "iconbtnLockBevestigen";
            this.iconbtnLockBevestigen.Size = new System.Drawing.Size(24, 24);
            this.iconbtnLockBevestigen.TabIndex = 6;
            this.iconbtnLockBevestigen.TabStop = false;
            this.iconbtnLockBevestigen.Click += new System.EventHandler(this.iconbtnLockBevestigen_Click);
            this.iconbtnLockBevestigen.MouseHover += new System.EventHandler(this.iconbtnLockBevestigen_MouseHover);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label11.Location = new System.Drawing.Point(275, 277);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 27);
            this.label11.TabIndex = 1;
            this.label11.Text = "Email*";
            // 
            // pnlEmail
            // 
            this.pnlEmail.BackColor = System.Drawing.Color.White;
            this.pnlEmail.Location = new System.Drawing.Point(281, 322);
            this.pnlEmail.Margin = new System.Windows.Forms.Padding(0);
            this.pnlEmail.Name = "pnlEmail";
            this.pnlEmail.Size = new System.Drawing.Size(232, 3);
            this.pnlEmail.TabIndex = 3;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmail.Font = new System.Drawing.Font("Myanmar Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtEmail.Location = new System.Drawing.Point(278, 303);
            this.txtEmail.MaxLength = 30;
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(236, 20);
            this.txtEmail.TabIndex = 8;
            this.txtEmail.Click += new System.EventHandler(this.txtEmail_Click);
            this.txtEmail.Enter += new System.EventHandler(this.txtEmail_Enter);
            this.txtEmail.Leave += new System.EventHandler(this.txtEmail_Leave);
            // 
            // lblVerplichtVeld
            // 
            this.lblVerplichtVeld.AutoSize = true;
            this.lblVerplichtVeld.Font = new System.Drawing.Font("Myanmar Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVerplichtVeld.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblVerplichtVeld.Location = new System.Drawing.Point(18, 400);
            this.lblVerplichtVeld.Name = "lblVerplichtVeld";
            this.lblVerplichtVeld.Size = new System.Drawing.Size(91, 20);
            this.lblVerplichtVeld.TabIndex = 14;
            this.lblVerplichtVeld.Text = "(*) verplicht veld";
            // 
            // Registratiescherm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 34F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(528, 464);
            this.Controls.Add(this.lblVerplichtVeld);
            this.Controls.Add(this.iconbtnLockBevestigen);
            this.Controls.Add(this.iconbtnLock);
            this.Controls.Add(this.btnNaarLogin);
            this.Controls.Add(this.btnRegistreren);
            this.Controls.Add(this.txtGemeente);
            this.Controls.Add(this.pnlgemeente);
            this.Controls.Add(this.txtPostcode);
            this.Controls.Add(this.pnlpostcode);
            this.Controls.Add(this.txtHuisNummer);
            this.Controls.Add(this.pnlhuisnummer);
            this.Controls.Add(this.txtStraat);
            this.Controls.Add(this.pnlstraat);
            this.Controls.Add(this.txtFamilienaam);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pnlfamilie);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtVoornaam);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pnlvoornaam);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtWachtwoordBevestigen);
            this.Controls.Add(this.txtWachtwoord);
            this.Controls.Add(this.pnlwwbevestigen);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtGebruikersnaam);
            this.Controls.Add(this.pnlww);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pnlEmail);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pnlgebruikersnaam);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.iconbtnOpenLockBevestigen);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.iconbtnOpenLock);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Myanmar Text", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Red;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.MaximizeBox = false;
            this.Name = "Registratiescherm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registreren";
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnLock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnOpenLock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnOpenLockBevestigen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconbtnLockBevestigen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlgebruikersnaam;
        private System.Windows.Forms.TextBox txtGebruikersnaam;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlvoornaam;
        private System.Windows.Forms.TextBox txtVoornaam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnlfamilie;
        private System.Windows.Forms.TextBox txtFamilienaam;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnlstraat;
        private System.Windows.Forms.TextBox txtStraat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnlpostcode;
        private System.Windows.Forms.TextBox txtPostcode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel pnlhuisnummer;
        private System.Windows.Forms.TextBox txtHuisNummer;
        public System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnlgemeente;
        private System.Windows.Forms.TextBox txtGemeente;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnlww;
        private System.Windows.Forms.TextBox txtWachtwoord;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel pnlwwbevestigen;
        private System.Windows.Forms.TextBox txtWachtwoordBevestigen;
        private System.Windows.Forms.Button btnRegistreren;
        private System.Windows.Forms.Button btnNaarLogin;
        private FontAwesome.Sharp.IconPictureBox iconbtnLock;
        private FontAwesome.Sharp.IconPictureBox iconbtnOpenLock;
        private FontAwesome.Sharp.IconPictureBox iconbtnOpenLockBevestigen;
        private FontAwesome.Sharp.IconPictureBox iconbtnLockBevestigen;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel pnlEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblVerplichtVeld;
        private System.Windows.Forms.ToolTip ToolTip;
    }
}